import java.util.ArrayList;

public interface Dealer {
    public ArrayList<Card> dealHand();
}
